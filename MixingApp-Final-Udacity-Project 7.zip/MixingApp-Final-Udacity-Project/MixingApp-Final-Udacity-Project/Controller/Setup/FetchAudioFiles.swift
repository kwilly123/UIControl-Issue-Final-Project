//
//  FetchAudioFiles.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-26.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import Firebase
import AVFoundation
import UIKit

extension TracksViewController {
    
    func fetchAudioFile(indexPath: IndexPath) {
        let storageRef = Storage.storage().reference().child(self.userID!).child(self.projectKey!).child("audiofiles").child("track\(indexPath.row)").child("audio.mp3")
        let fileManager = FileManager.default
        storageRef.downloadURL { (url, error) in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            if let url = url {
                
                if let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) {
                    
                    let filePath = documentDirectory.appendingPathComponent(url.lastPathComponent)
                    print("URL: \(url)")
                    
                    guard let audioFileData = try? Data(contentsOf: url) else { return }
                    
                    try? audioFileData.write(to: filePath)
                    
                    var file: AVAudioFile!
                    
                    do {
                        try file = AVAudioFile(forReading: (filePath))
                        print(file.length)
//                        let format = AVAudioFormat(commonFormat: .pcmFormatInt32, sampleRate: file.fileFormat.sampleRate, channels: file.fileFormat.channelCount, interleaved: false)
//                        let buf = AVAudioPCMBuffer(pcmFormat: format!, frameCapacity: UInt32(file.length))
//                        try file.read(into: buf!)
                        
                        if let cell: TrackCell = self.collectionView.cellForItem(at: indexPath) as? TrackCell {
//                            cell.audioPlayer?.scheduleBuffer(buf!, completionHandler: {
//                                print("SCHEDULED BUF")
//                            })
                            let equalizer = AVAudioUnitEQ(numberOfBands: 4)
                            self.setupEQ(equalizer: equalizer)
                            self.audioPlayers.remove(at: indexPath.row)
                            self.audioPlayers.insert(cell.audioPlayer, at: indexPath.row)
                            self.equalizers.remove(at: indexPath.row)
                            self.equalizers.insert(equalizer, at: indexPath.row)
                            self.audioEngine.attach(cell.audioPlayer!)
                            self.audioEngine.attach(equalizer)
                            self.audioEngine.connect(cell.audioPlayer!, to: equalizer, format: nil)
                            self.audioEngine.connect(equalizer, to: self.mixer, format: nil)
                        }
                        
                        
                        self.filesArray.remove(at: indexPath.row)
                        self.filesArray.insert(file, at: indexPath.row)
                        print("INDEX: \(indexPath)")
                        if let cell: TrackCell = self.collectionView.cellForItem(at: indexPath) as? TrackCell {
                            cell.buttonRemove.isEnabled = true
                            cell.buttonRemove.alpha = 1.0
                            cell.importLight.backgroundColor = .blue
                            cell.buttonImport.isEnabled = false
                            cell.buttonImport.alpha = 0.5
                        }
                    } catch {
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
    
}
