//
//  FirebaseAPI.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-25.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import Firebase
import UIKit

class FirebaseClient {
    
    enum Endpoints {
        static let database = Database.database().reference()
        static let user = "user_profiles"
        //unique id
        static let projects = "projects"
        //project unique key
        static let tracks = "tracks"
        //track #
        
        case fetchProject(String)
        case fetchTracks
    }
    
}
